import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.drinksanddelight.dao.ProductOrderDao;
import com.capgemini.drinksanddelight.entities.ProductOrderEntity;
import com.capgemini.drinksanddelight.service.ProductOrderService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootMockitoTests {
	
	
	@InjectMocks
	private ProductOrderService service;
	
	@MockBean
	private ProductOrderDao repo;
	
	@Test
	public void addOrderTest() {
		LocalDate date = LocalDate.of(2020, 02, 02);
		ProductOrderEntity  order = new ProductOrderEntity("kapil","a22",10.0,10.0,10.0,date,100.0);
		when(repo.save(order)).thenReturn(order);
		
		assertEquals(order, service.save(order));
	}

}
