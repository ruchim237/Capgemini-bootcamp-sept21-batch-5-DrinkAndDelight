package com.capgemini.drinksanddelight.controller;

import com.capgemini.drinksanddelight.dto.ProductOrderDetails;
import com.capgemini.drinksanddelight.util.ProductOrderUtil;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.capgemini.drinksanddelight.dto.CreateProductOrderRequest;
import com.capgemini.drinksanddelight.entities.ProductOrderEntity;
import com.capgemini.drinksanddelight.service.ProductOrderService;

/*
@author NAVDEEP TRIPATHI
*/
@RestController
@RequestMapping("/products/orders")
public class ProductOrderController {


    @Autowired
    private ProductOrderService productOrderService;
    
    
    @GetMapping
    public ResponseEntity<List<CreateProductOrderRequest>> fetchAll() {
        List<ProductOrderEntity>  orders = productOrderService.fetchAll();
        List<CreateProductOrderRequest> list =ProductOrderUtil.toOrderEntityDto(orders);
        ResponseEntity<List<CreateProductOrderRequest>> response = new ResponseEntity<>(list, HttpStatus.OK);
        return response;
    }
    

    @PostMapping("/add")
    public ResponseEntity<ProductOrderDetails> addProduct(@RequestBody CreateProductOrderRequest requestData) {
        ProductOrderEntity order = ProductOrderUtil.toOrderEntity(requestData);
        order = productOrderService.save(order);
        ProductOrderDetails details=ProductOrderUtil.toOrderDetails(order);
        ResponseEntity<ProductOrderDetails> response = new ResponseEntity<>(details, HttpStatus.OK);
        return response;
    }


    @GetMapping("/get/{id}")
    public ResponseEntity<ProductOrderDetails> trackOrder(@PathVariable("id") String id)  {
        ProductOrderEntity order = productOrderService.trackOrder(id);
        ProductOrderDetails details=ProductOrderUtil.toOrderDetails(order);
        return new ResponseEntity<ProductOrderDetails>(details, HttpStatus.OK);
    }
    
    @DeleteMapping("/delete/{orderId}")
    public ResponseEntity<Boolean> deleteOrder(@PathVariable("OrderId") String orderId) {
        boolean result = productOrderService.deleteOrder(orderId);
        ResponseEntity respose = new ResponseEntity(result, HttpStatus.OK);
        return respose;
        
    }


}
