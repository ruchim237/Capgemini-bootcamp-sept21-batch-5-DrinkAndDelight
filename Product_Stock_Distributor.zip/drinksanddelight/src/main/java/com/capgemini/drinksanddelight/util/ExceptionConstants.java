package com.capgemini.drinksanddelight.util;

/*
@author NAVDEEP TRIPATHI
*/

public class ExceptionConstants {
	public static final String ID_NOT_EXIST="Order id not exist";
}
