package com.capgemini.drinksanddelight.dto;

public class CreateDistributorRequest {
	private String distributor_Id;

	private String distributor_Name;

	private String distributor_Address;

	private String distributor_Phn;

	public String getDistributor_Id() {
		return distributor_Id;
	}

	public void setDistributor_Id(String distributor_Id) {
		this.distributor_Id = distributor_Id;
	}

	public String getDistributor_Name() {
		return distributor_Name;
	}

	public void setDistributor_Name(String distributor_Name) {
		this.distributor_Name = distributor_Name;
	}

	public String getDistributor_Address() {
		return distributor_Address;
	}

	public void setDistributor_Address(String distributor_Address) {
		this.distributor_Address = distributor_Address;
	}

	public String getDistributor_Phn() {
		return distributor_Phn;
	}

	public void setDistributor_Phn(String distributor_Phn) {
		this.distributor_Phn = distributor_Phn;
	}
	
	
}
